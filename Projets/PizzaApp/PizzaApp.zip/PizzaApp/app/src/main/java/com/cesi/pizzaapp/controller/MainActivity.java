package com.cesi.pizzaapp.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.cesi.pizzaapp.R;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<String> pizzas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.createPizzas();
    }

    private void createPizzas(){

    }
}